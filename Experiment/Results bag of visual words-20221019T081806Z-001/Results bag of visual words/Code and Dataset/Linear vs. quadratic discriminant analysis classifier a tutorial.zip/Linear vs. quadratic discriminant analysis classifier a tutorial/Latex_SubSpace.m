%% This example to explain the Subspace method (Section 4.3)
% This code was written by Alaa Tharwat and for any other questions send to
% me Email: engalaatharwat@hotmail.com
% Alaa Tharwat, "Linear vs. quadratic discriminant analysis classifier: a
% tutorial", Int. J. Applied Pattern Recognition, Vol. 3, No. 2, 2016, pp.
% 145-180.

clc
clear all
%% The data of three classes
C1=[3 4 3 5; 3 5 6 4; 4 4 5 7]
C2=[3 2 5 2; 3 3 5 3; 4 2 3 5]
C3=[6 2 5 6; 6 3 6 7; 7 2 5 7]
%% Calculate the number of samples in each class (ni)
n1=size(C1,1);
n2=size(C2,1);
n3=size(C3,1);
%%Reduce the dimension of all samples in all classes to be only two
%%features
[vec1,eval1]=pca_new_final(C1')
NewC_1=C1*vec1(:,1:2)

[vec2,eval2]=pca_new_final(C2')
NewC_2=C2*vec2(:,1:2)

[vec3,eval3]=pca_new_final(C3')
NewC_3=C3*vec3(:,1:2)
%% Calculate the mean of each class (mui)
mu1=mean(NewC_1)
mu2=mean(NewC_2)
mu3=mean(NewC_3)
%% Subtract the mean of each class from the class samples (mean-centring data) (Di=Ci-mui)
D1=NewC_1-repmat(mu1,n1,1)
D2=NewC_2-repmat(mu2,n2,1)
D3=NewC_3-repmat(mu3,n3,1)
%% Calculate the covariance matrix of each class (Covi)
Cov1=D1'*D1
Cov2=D2'*D2
Cov3=D3'*D3
%% Calculate the inverse of the covariance matrices
invCov1=inv(Cov1);
invCov2=inv(Cov2);
invCov3=inv(Cov3);

