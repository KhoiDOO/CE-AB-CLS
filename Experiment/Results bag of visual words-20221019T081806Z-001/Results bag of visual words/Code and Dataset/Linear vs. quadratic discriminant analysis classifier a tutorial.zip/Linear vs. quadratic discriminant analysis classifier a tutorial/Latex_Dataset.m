%This example to explian how the LDA is used as a classifier (Section 5)
% This code was written by Alaa Tharwat and for any other questions send to
% me Email: engalaatharwat@hotmail.com
% Alaa Tharwat, "Linear vs. quadratic discriminant analysis classifier: a
% tutorial", Int. J. Applied Pattern Recognition, Vol. 3, No. 2, 2016, pp.
% 145-180.

clc
clear all
%% Load the labeled dataset (iris dataset)
%% data (Nxm) where N is the number of samples and m is the dimension of each sample
%% Y is the labels of the samples
load iris
%% Sort the samples randomly
y=randperm(size(data,1));
data=data(y,:);
Labels=Y(y);
%% Per is the percentage of the training samples and 1-Per is the percentage of the testing samples
Per=0.9;
Tr=data(1:ceil(Per*size(data,1)),:);
Test=data(1+ceil(Per*size(data,1)):end,:);
TrL=Labels(1:ceil(Per*size(data,1)),:);
TestL=Labels(1+ceil(Per*size(data,1)):end,:);
%% Train the model using linear and quadratic discriminant classifiers
%% Linera Discriminant Analysis (ldaclass is the prediction of the testing samples)
[ldaclass,err,p,logp,coeff]=classify(Test,Tr,TrL,'linear');
disp(['Linear accuracy is ' int2str(100*sum(ldaclass==TestL)/size(TestL,1))])
%% Quadratic Discriminant Analysis (ldaclass is the prediction of the testing samples)
[ldaclassQ,err,p,logp,coeff]=classify(Test,Tr,TrL,.....
    'Quadratic');
disp(['Quadratic accuracy is ' int2str(100*sum(ldaclassQ==TestL)/size(TestL,1))])