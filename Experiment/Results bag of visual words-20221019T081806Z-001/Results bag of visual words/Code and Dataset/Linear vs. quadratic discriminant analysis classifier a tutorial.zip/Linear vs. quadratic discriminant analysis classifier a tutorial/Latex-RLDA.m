%% This example to explain the regularized-LDA (RLDA) (Section 4.2)
% This code was written by Alaa Tharwat and for any other questions send to
% me Email: engalaatharwat@hotmail.com
% Alaa Tharwat, "Linear vs. quadratic discriminant analysis classifier: a
% tutorial", Int. J. Applied Pattern Recognition, Vol. 3, No. 2, 2016, pp.
% 145-180.

clc
clear all
%% The data of three classes
C1=[3 4 3 5; 3 5 6 4; 4 4 5 7]
C2=[3 2 5 2; 3 3 5 3; 4 2 3 5]
C3=[6 2 5 6; 6 3 6 7; 7 2 5 7]
%% Calculate the number of samples in each class (ni)
n1=size(C1,1);
n2=size(C2,1);
n3=size(C3,1);
n=n1+n2+n3
%% Calculate the mean of each class (mui)
mu1=mean(C1)
mu2=mean(C2)
mu3=mean(C3)
%% Subtract the mean of each class from the class samples (mean-centring data) (Di=Ci-mui)
D1=C1-repmat(mu1,n1,1)
D2=C2-repmat(mu2,n2,1)
D3=C3-repmat(mu3,n3,1)
%% Calculate the covariance matrix of each class (Covi)
Cov1=D1'*D1
Cov2=D2'*D2
Cov3=D3'*D3
%% Calculate the new covariance matrices of each class (Covi=Covi+eta*Covi)
eta=0.05;
Rcov1= Cov1+eta* eye(size(Cov1,1),size(Cov1,2))
Rcov2= Cov2+eta* eye(size(Cov2,1),size(Cov2,2))
Rcov3= Cov3+eta* eye(size(Cov3,1),size(Cov3,2))
%% Calculate the inverse of the covariance matrices
invCov1=inv(Rcov1);
invCov2=inv(Rcov2);
invCov3=inv(Rcov3);