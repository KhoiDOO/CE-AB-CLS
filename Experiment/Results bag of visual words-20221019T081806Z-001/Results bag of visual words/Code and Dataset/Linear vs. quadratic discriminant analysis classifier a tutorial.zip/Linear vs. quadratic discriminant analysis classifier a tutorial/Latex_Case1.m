% This is a MATLAB code for the first numerical example (Section 3.1)
% This code was written by Alaa Tharwat and for any other questions send to
% me Email: engalaatharwat@hotmail.com
% Alaa Tharwat, "Linear vs. quadratic discriminant analysis classifier: a
% tutorial", Int. J. Applied Pattern Recognition, Vol. 3, No. 2, 2016, pp.
% 145-180.

clc
clear all;
%% The data of the three classes
C1=[3 4;3 5;4 4;4 5]
C2=[3 2;3 3;4 2;4 3]
C3=[6 2;6 3;7 2;7 3]
%% Calculate the number of samples in each class (ni)
n1=size(C1,1);
n2=size(C2,1);
n3=size(C3,1);
%% Calculate the total number of samples (N=n1+n2+n3)
N=n1+n2+n3
%% Calculate the mean of each class (mui)
mu1=mean(C1)
mu2=mean(C2)
mu3=mean(C3)
%% Subtract the mean of each class from the class samples (mean-centring data) (Di=Ci-mui)
D1=C1-repmat(mu1,n1,1)
D2=C2-repmat(mu2,n2,1)
D3=C3-repmat(mu3,n3,1)
%% Calculate the covariance matrix of each class (Covi)
Cov1=D1'*D1
Cov2=D2'*D2
Cov3=D3'*D3
%% Calculate the inverse of the covariance matrices
invCov1=inv(Cov1);
invCov2=inv(Cov2);
invCov3=inv(Cov3);
%% Calculate the prior probability (Pi)
P1=n1/N
P2=n2/N
P3=n3/N
%% Calculate the discriminant functions of all classes
%% In this case (Case 1): Wi0 represents the bias term, Wi is the coefficients of the linear term, and WWi is the qudaratic term
%% Note: the inverse of all covariance matrices are equal, hence the values of the quadratic coefficients are the same 
W10=log(P1)-0.5*mu1*((invCov1)*mu1')
W1=(invCov1)*mu1'
WW1=-0.5*inv(Cov1)

W20=log(P2)-0.5*mu2*((invCov2)*mu2')
W2=(invCov2)*mu2'
WW2=-0.5*inv(Cov2)

W30=log(P3)-0.5*mu3*((invCov3)*mu3')
W3=(invCov3)*mu3'
WW3=-0.5*inv(Cov3)